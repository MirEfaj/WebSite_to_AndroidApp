package com.efaj.apple.helper;

public interface MyHelper {
    void loading();
    void finishLoading();
    void webGoBack();

    void webLoadUrl(String url);
    void errorLoading();

} // myHelper End Here ===========
